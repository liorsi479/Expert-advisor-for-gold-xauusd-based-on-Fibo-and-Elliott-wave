# EA-Robots-for-gold-xauusd-based-on-Fibo-and-Elliott-wave
Scalping gold (fibo and Elliott wave)
